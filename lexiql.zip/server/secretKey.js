const secretKey = '),E?/*viF%ul,.d';

module.exports = secretKey;
