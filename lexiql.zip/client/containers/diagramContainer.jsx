import React from 'react';
import TableNode from '../components/tableNode';

export default function diagramContainer() {
  return (
    <div className="diagramContainer">
      <TableNode />
    </div>
  );
}
