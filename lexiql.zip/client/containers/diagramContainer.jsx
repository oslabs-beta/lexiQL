import React from 'react';
import FlowContainer from './flowContainer';

export default function diagramContainer() {
  return (
    <div className="diagramContainer">
      <FlowContainer />
    </div>
  );
}
