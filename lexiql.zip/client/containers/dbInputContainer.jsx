import React from 'react';
import URIForm from '../components/URIForm.jsx';

export default function dbInputContainer() {
  return (
    <div className="dbInputContainer">
      <URIForm />
    </div>
  );
}
