import React from 'react';
import FormContainer from './formContainer.jsx';

export default function dbInputContainer() {
  return (
    <div className="dbInputContainer">
      <FormContainer />
    </div>
  );
}
