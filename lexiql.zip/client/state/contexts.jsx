import { createContext } from 'react';

export const DiagramContext = createContext();
export const CodeContext = createContext();
export const FormContext = createContext();
