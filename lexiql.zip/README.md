# lexiQL

An open-source GraphQL tool that visualizes your relational database relationships and facilitates GraphQL API prototyping and configuration. Currently in production.

COMING APRIL 2021!